console.log('Detail script injected and running...');

// MutationObserver để click vào button khi xuất hiện
const processedIdx = new Set(); 

const buttonObserver = new MutationObserver(() => {
  const button = document.querySelector("button[class*='label-file-']");
  if (button) {
    console.log("Button found, clicking...");
    button.click();
    buttonObserver.disconnect(); // Dừng quan sát khi đã click
  }
});

buttonObserver.observe(document.body, { childList: true, subtree: true });

// Kiểm tra nếu button đã có sẵn để click ngay lập tức
const button = document.querySelector("button[class*='label-file-']");
if (button) {
  console.log("Button found immediately, clicking...");
  button.click();
  buttonObserver.disconnect();
}

// Hàm observeImage đã loại bỏ data-status
function observeImage(imgIndex) {
  console.log(`observeImage`, imgIndex)
  return new Promise((resolve) => {
    let seoValue = "";
    let imageObserver;

    // Function to extract SEO value
    const getSeoValue = () => {
      document.querySelectorAll("#list-create-transfer-ajax tr td .word-break").forEach(element => {
        const match = element.innerText.match(/\[?(SEO \d+)\]?/);
        if (match) {
          seoValue = match[1];
        }
      });
    };

    // Function to handle image loading
    const handleImage = (image, objectId) => {
      const onImageLoad = () => {
        console.log(`imageObserver`, imageObserver)
        if (imageObserver) {
          imageObserver.disconnect(); // Ngừng theo dõi ảnh khi đã xử lý xong
        }
        handleImageLoad(image, objectId.value, seoValue, imgIndex); // Xử lý ảnh khi tải xong
        resolve(); // Resolve Promise khi ảnh được tải
      };

      // Nếu ảnh đã tải xong hoặc ảnh đang tải
      if (image.complete && image.naturalHeight !== 0) {
        onImageLoad();
      } else {
        image.onload = onImageLoad; // Thiết lập sự kiện onload nếu ảnh chưa tải
      }
    };

    // MutationObserver theo dõi sự thay đổi trong DOM
    imageObserver = new MutationObserver(() => {
      const image = document.querySelector("img.main-img");
      const objectId = document.getElementById("object-id");

      // Lấy SEO value khi có thay đổi trong DOM
      getSeoValue();

      // Kiểm tra nếu ảnh và objectId tồn tại
      if (image && image.src && objectId && objectId.value) {
        console.log("handleImage from observer:", image);
        handleImage(image, objectId); // Xử lý ảnh
      }
    });

    imageObserver.observe(document.body, { childList: true, subtree: true });

    // Kiểm tra ảnh và objectId đã có chưa
    const image = document.querySelector("img.main-img");
    const objectId = document.getElementById("object-id");

    // Lấy SEO value ngay lập tức nếu có
    getSeoValue();

    // Kiểm tra ảnh và objectId, xử lý ngay nếu đã có
    if (image && image.src && objectId && objectId.value) {
      console.log("handleImage from initial check:", image);
      handleImage(image, objectId);
    }
  });
}

// Hàm chờ phần tử xuất hiện
function waitForElement(selector, callback) {
  const observer = new MutationObserver((mutations, obs) => {
    const element = document.querySelector(selector);
    if (element) {
      obs.disconnect(); // Dừng quan sát khi tìm thấy phần tử
      callback();
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// Đợi #_main_load_files xuất hiện và bắt đầu trackListAndClick
waitForElement("#_main_load_files", trackListAndClick);

// Hàm trackListAndClick được gọi khi phần tử đã xuất hiện

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
async function trackListAndClick() {
  const items = document.querySelectorAll("#_main_load_files .m-item a.item");
  console.log("Found", items.length, "items.");

  for (let index = 0; index < items.length; index++) {      
    if (index > 0) {
        items[index]?.click();
        await delay(1000);
        await observeImage(index);
    } else {
      await observeImage(index);
    }
}

  
  console.log("All items processed.");
  chrome.runtime.sendMessage({ action: "closeDetailPage" }); // Đóng trang sau khi xử lý tất cả mục
}

// Hàm xử lý tải ảnh
function handleImageLoad(image, objectIdValue, seoValue, imgIndex) {
  if (processedIdx.has(imgIndex)) return;
  processedIdx.add(imgIndex);
  console.log("✅ Image loaded:", image.src, 'object-id', objectIdValue);
  chrome.runtime.sendMessage({ action: "downloadImage", url: image.src, id: objectIdValue, seoValue: seoValue, imgIndex: imgIndex });
}

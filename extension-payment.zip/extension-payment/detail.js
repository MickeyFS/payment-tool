console.log('Detail script injected and running...');

const buttonObserver = new MutationObserver(() => {
  const button = document.querySelector("button[class*='label-file-']");
  if (button) {
    console.log("Button found, clicking...");
    button.click();
    buttonObserver.disconnect(); 
    observeImage();
  }
});

buttonObserver.observe(document.body, { childList: true, subtree: true });

const button = document.querySelector("button[class*='label-file-']");
if (button) {
  console.log("Button found immediately, clicking...");
  button.click();
  buttonObserver.disconnect();
  observeImage();
}

function observeImage() {
  const imageObserver = new MutationObserver(() => {
    const image = document.querySelector("img.main-img");
    const objectId = document.getElementById("object-id");
    if (image && image.src && objectId && objectId.value) {
      console.log("✅ Image found:", image.src, 'object-id', objectId.value);
      chrome.runtime.sendMessage({ action: "downloadImage", url: image.src, id: objectId.value });
      chrome.runtime.sendMessage({ action: "closeDetailPage" });
      imageObserver.disconnect(); 
    }
  });

  // Bắt đầu quan sát thay đổi trong body
  imageObserver.observe(document.body, { childList: true, subtree: true });

  // Kiểm tra ngay lập tức (nếu ảnh đã tồn tại)
  const image = document.querySelector("img.main-img");
  const objectId = document.getElementById("object-id");
  if (image && image.src && objectId && objectId.value) {
    console.log("✅ Image found immediately:", image.src);
    chrome.runtime.sendMessage({ action: "downloadImage", url: image.src, id: objectId.value });
    chrome.runtime.sendMessage({ action: "closeDetailPage" });    
    imageObserver.disconnect();
  }
}


importScripts("xlsx.full.min.js");
const MAX_TABS = 5;
let isTabRunning = 0;
let queue = [];
let currentWindowId = null;
let downloadedIds = new Map();
let lastDate = new Date().toISOString().split('T')[0];

function openDetail(message) {
  if (!message) return;
  if (message.date) {
    // compare last date and message date
    if (lastDate != message.date) {
      lastDate = message.date;
      chrome.storage.local.set({ 'lastDate' : lastDate });
      downloadedIds = new Map();
    }
  }
  downloadedIds.set(message.paymentId, 0);
  if (isTabRunning >= MAX_TABS) {
    queue.push(message.url);
    console.log("Added to queue: ", message.url);
  } else {
    if (currentWindowId === null) {
      chrome.windows.getCurrent((window) => {
        currentWindowId = window.id;
        openNewTab(message.url);
      });
    } else {
      openNewTab(message.url);
    }
    isTabRunning++;
  }
}
function generateExcelReport(message, sendResponse) {
  if (!message) return;
  if (!sendResponse) return;

  const data = [["ID", "Trạng thái"]];

  downloadedIds.forEach((status, id) => {
    data.push([id, status == 1 ? "Thành công" : ""]);
  });
  const ws = XLSX.utils.aoa_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, `Danh sách payment ${lastDate}`);

  const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob = new Blob([wbout], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  const reader = new FileReader();
  reader.onload = function (event) {
    const base64Data = event.target.result.split(",")[1]; // Lấy phần base64
    sendResponse({ success: true, data: base64Data });
  };
  reader.readAsDataURL(blob);

  return true; // Quan trọng: Giữ kết nối async với sendResponse
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case "openDetailPage":
      openDetail(message);
      break;

    case "closeDetailPage":
      closeTab(sender.tab.id);
      break;

    case "excel":
      return generateExcelReport(message, sendResponse);

    case "downloadImage":
      downloadImage(message.url, message.id);
      sendResponse({ status: "Download started" });
      break;
  }
});

function openNewTab(url) {
  console.log(`Opening new tab. Running tabs: ${isTabRunning}`);
  chrome.tabs.create(
    { windowId: currentWindowId, url: url, active: false },
    (tab) => {
      chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
        if (tabId === tab.id && changeInfo.status === "complete") {
          chrome.tabs.onUpdated.removeListener(listener);
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["detail.js"],
          });
        }
      });
      // Đóng tab sau 10 giây nếu `detail.js` không gửi tín hiệu đóng
      setTimeout(() => {
        chrome.tabs.remove(tab.id, () => {
          console.log(`Tab ${tab.id} auto-closed after timeout.`);
          closeTab(tab.id);
        });
      }, 10000); // 10 giây
    }
  );
}

function closeTab(tabId) {
  chrome.tabs.remove(tabId, () => {
    isTabRunning = Math.max(0, isTabRunning - 1); // Đảm bảo không giảm âm
    console.log(`Tab ${tabId} closed. Running tabs: ${isTabRunning}`);

    // Nếu có tab trong hàng đợi, mở tab mới
    if (queue.length > 0 && isTabRunning < MAX_TABS) {
      const nextUrl = queue.shift();
      openNewTab(nextUrl);
    }
  });
}

function downloadImage(imageUrl, id) {
  console.log("🚀 Downloading image:", imageUrl);
  const filename = `${id}.jpg`;
  chrome.downloads.download(
    {
      url: imageUrl,
      filename: filename,
      saveAs: false,
    },
    (downloadId) => {
      console.log("Downloading image", downloadId);
      if (chrome.runtime.lastError) {
        console.error("❌ Error downloading image:", chrome.runtime.lastError);
      } else {
        console.log("✅ Image downloaded successfully!", downloadId);
        downloadedIds.set(id, 1);
      }
    }
  );
}

function calculateTime(alarmTime) {
  const now = new Date();
  const [hours, minutes] = alarmTime.split(":").map(Number);
  const timer = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate(),
    hours,
    minutes
  );

  if (now >= timer) {
    timer.setDate(timer.getDate() + 1);
  }
  return timer - now;
}
async function openUrl() {
  downloadedIds = new Map();
  lastDate = new Date().toISOString().split('T')[0];
  chrome.storage.local.set({ 'lastDate' : lastDate });
  chrome.storage.local.get("urlAll", (data) => {
    chrome.tabs.create(
      {
        url: data.urlAll || "https://portal.atk8zpl.com/admincp/apjournal",
      },
      (tab) => {
        setTimeout(() => {
          chrome.tabs.sendMessage(tab.id, {
            action: "update",
            date: lastDate,
            // ANCHOR - Change
          });
          console.log("Send message to chrome runtime");
        }, 1000); // Set timeout to 1 second before sending the message
      }
    );
  });
}
var myTimeout;
var myInterval;
function setUpTimer(alarmTime) {
  if (myTimeout) {
    console.log("Clear timeout ", myTimeout);
    clearTimeout(myTimeout);
  }
  if (myInterval) {
    console.log("Clear interval ", myInterval);
    clearInterval(myInterval);
  }
  console.log(`Alarm time: ${alarmTime}`);
  const countTime = calculateTime(alarmTime);
  console.log(`Count time: ${countTime}`);

  myTimeout = setTimeout(() => {
    openUrl();
    myInterval = setInterval(openUrl, 86400000); //24*60*60*1000
    console.log(`⏰ Interval: ${myInterval}`);
  }, countTime);
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get("alarmTime", (data) => {
    if (data.alarmTime) {
      setUpTimer(data.alarmTime);
    }
  });
chrome.storage.local.remove("lastDate");
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.alarmTime?.newValue) {
    const alarmTime = changes.alarmTime.newValue;
    setUpTimer(alarmTime);
  }
});

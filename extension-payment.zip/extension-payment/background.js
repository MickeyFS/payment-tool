importScripts("xlsx.full.min.js");
// ANCHOR
const MAX_TABS = 5;
let isTabRunning = 0;
let queue = [];
let currentWindowId = null;
let downloadedIds = new Map();
let lastDate = new Date().toISOString().split('T')[0];

function openDetail(message) {
  if (!message) return;
  if (message.date) {
    // compare last date and message date
    if (lastDate != message.date) {
      lastDate = message.date;
      chrome.storage.local.set({ 'lastDate' : lastDate });
      downloadedIds = new Map();
    }
  }
  downloadedIds.set(message.paymentId, {
    status: 0,
    startDate: message.startDate,
    endDate: message.endDate
  });
  if (isTabRunning >= MAX_TABS) {
    queue.push(message.url);
    console.log("Added to queue: ", message.url);
  } else {
    if (currentWindowId === null) {
      chrome.windows.getCurrent((window) => {
        currentWindowId = window.id;
        openNewTab(message.url);
      });
    } else {
      openNewTab(message.url);
    }
    isTabRunning++;
  }
}
function generateExcelReport(message, sendResponse) {
  console.log("Generating Excel report...");
  if (!message) return;
  if (!sendResponse) return;

  var data = [["ID", "TEAM", "NGÀY TẠO", "NGÀY CẬP NHẬT", "TRẠNG THÁI"]];

  downloadedIds.forEach((value, id) => {
    data.push([
      id,
      value.team ?? "",
      value.startDate ?? "",
      value.endDate ?? "",
      value.status == 1 ? "Thành công" : ""]);
  });
  const ws = XLSX.utils.aoa_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, lastDate ? `${lastDate}` : 'Danh sách payment');

  const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob = new Blob([wbout], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  const reader = new FileReader();
  reader.onload = function (event) {
    const base64Data = event.target.result.split(",")[1]; // Lấy phần base64
    sendResponse({ success: true, data: base64Data });
  };
  reader.readAsDataURL(blob);

  return true; // Quan trọng: Giữ kết nối async với sendResponse
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case "openDetailPage":
      openDetail(message);
      break;

    case "closeDetailPage":
      closeTab(sender.tab.id);
      break;

    case "excel":
      return generateExcelReport(message, sendResponse);

    case "downloadImage":
      downloadImage(message.url, message.id, message.seoValue, message.imgIndex);
      sendResponse({ status: "Download started" });
      break;
  }
});

function openNewTab(url) {
  console.log(`Opening new tab. Running tabs: ${isTabRunning}`);
  chrome.tabs.create(
    { windowId: currentWindowId, url: url, active: false },
    (tab) => {
      chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
        if (tabId === tab.id && changeInfo.status === "complete") {
          chrome.tabs.onUpdated.removeListener(listener);
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["detail.js"],
          });
        }
      });
      // ANCHOR
      // Đóng tab sau 10 giây nếu `detail.js` không gửi tín hiệu đóng
      setTimeout(() => {
        chrome.tabs.remove(tab.id, () => {
          console.log(`Tab ${tab.id} auto-closed after timeout.`);
          closeTab(tab.id);
        });
      }, 10000); // 10 giây
    }
  );
}

function closeTab(tabId) {
  chrome.tabs.remove(tabId, () => {
    isTabRunning = Math.max(0, isTabRunning - 1); // Đảm bảo không giảm âm
    console.log(`Tab ${tabId} closed. Running tabs: ${isTabRunning}`);

    // Nếu có tab trong hàng đợi, mở tab mới
    if (queue.length > 0 && isTabRunning < MAX_TABS) {
      const nextUrl = queue.shift();
      openNewTab(nextUrl);
    }
  });
}

function downloadImage(imageUrl, id, seoValue, idx=0) {
  console.log("🚀 Downloading image:", imageUrl);
  console.log("Team: ", seoValue)
  downloadedIds.set(id, {
    ...downloadedIds.get(id),
    team: seoValue,
  });
  idx = typeof idx === 'number' && !isNaN(idx) ? idx + 1 : 1;
  let filename = seoValue ? `${seoValue}-${id}-${idx}.jpg` : `${id}-${idx}.jpg`;

  chrome.downloads.download(
    {
      url: imageUrl,
      filename: filename,
      saveAs: false,
    },
    (downloadId) => {
      console.log("Downloading image", downloadId);
      if (chrome.runtime.lastError) {
        console.error("❌ Error downloading image:", chrome.runtime.lastError);
      } else {
        console.log("✅ Image downloaded successfully!", downloadId);
        downloadedIds.set(id, {
          ...downloadedIds.get(id),
          status: 1,
        });
      }
    }
  );
}

function calculateTime(alarmTime) {
  const now = new Date();
  const [hours, minutes] = alarmTime.split(":").map(Number);
  const timer = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate(),
    hours,
    minutes
  );

  if (now >= timer) {
    timer.setDate(timer.getDate() + 1);
  }
  return timer - now;
}
async function openUrl() {
  downloadedIds = new Map();
  lastDate = new Date().toISOString().split('T')[0];
  chrome.storage.local.set({ 'lastDate' : lastDate });
  chrome.storage.local.get("urlAll", (data) => {
    chrome.tabs.create(
      {
        url: data.urlAll || "https://portal.atk8zpl.com/admincp/apjournal",
      },
      (tab) => {
        setTimeout(() => {
          chrome.tabs.sendMessage(tab.id, {
            action: "update",
            date: [lastDate],
          });
          console.log("Send message to chrome runtime");
        }, 1000); // Set timeout to 1 second before sending the message
      }
    );
  });
}
var myTimeout;
var myInterval;
function setUpTimer(alarmTime) {
  if (myTimeout) {
    console.log("Clear timeout ", myTimeout);
    clearTimeout(myTimeout);
  }
  if (myInterval) {
    console.log("Clear interval ", myInterval);
    clearInterval(myInterval);
  }
  console.log(`Alarm time: ${alarmTime}`);
  const countTime = calculateTime(alarmTime);
  console.log(`Count time: ${countTime}`);

  myTimeout = setTimeout(() => {
    openUrl();
    myInterval = setInterval(openUrl, 86400000); //24*60*60*1000
    console.log(`⏰ Interval: ${myInterval}`);
  }, countTime);
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["alarmTime", "switchTimer"], (data) => {
    if (data.switchTimer===false) return;
    if (data.alarmTime) {
      setUpTimer(data.alarmTime);
    }
  });
  chrome.storage.local.remove("lastDate");
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.alarmTime?.newValue) {
    const alarmTime = changes.alarmTime.newValue;
    setUpTimer(alarmTime);
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "startTimer") {
    setUpTimer(message.alarmTime);
  } else if (message.action === "stopTimer") { 
    if (myTimeout) {
      clearTimeout(myTimeout);
      myTimeout = null;
    }
    if (myInterval) {
      clearInterval(myInterval);
      myInterval = null;
    }
    console.log("Timer stopped");
  }
})

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action == 'updateSheet') {
    if (downloadedIds.size === 0) {
      console.log("No data to update.");
      sendResponse({ error: "Không có dữ liệu cập nhật" });
      return;
    }
    getToken().then((token) => {
      console.log(token);
      // ANCHOR
      chrome.storage.local.get(["sheetId", "sheetName"], (data) => {
        const spreadsheetId = data.sheetId;
        const sheetName = data.sheetName;

        if (!spreadsheetId || !sheetName) {
          console.error("Sheet ID or Sheet Name is missing.");
          sendResponse({ error: "Sheet ID hoặc Sheet Name bị thiếu." });
          return;
        }
        console.log("Sheet ID:", spreadsheetId);
        console.log("Sheet Name:", sheetName);
        readGoogleSheetData(spreadsheetId, sheetName, token).then((data) => {
          const updates = [];
  
          data.forEach((rowId, index) => {
            const id = rowId[0];
            if (downloadedIds.has(id)) {
              const val = downloadedIds.get(id);
              if (val.endDate) {
                const fmEndDate = formatEndDate(val.endDate);
                console.log(`ID ${id} đã có trong downloadedIds tại hàng ${index + 2}.`, fmEndDate);
                updates.push({ position: `N${index + 2}`, value: fmEndDate });
              }
            }
          });
          
          // Nếu có cập nhật, gọi updateCells một lần duy nhất
          if (updates.length > 0) {
            updateCells(spreadsheetId, sheetName, updates, token)
              .then(() => {
                sendResponse({ status: "Cập nhật thành công" });
              })
              .catch(error => {
                console.error("Lỗi khi cập nhật hàng loạt:", error)
                sendResponse({ error: `Cập nhật lỗi: ${error.message}` });
              });
          } else {
            console.log("Không có dữ liệu nào cần cập nhật.");
            sendResponse({ status: "Không có dữ liệu nào cần cập nhật." });
          }
          
        }).catch(error => {
          console.error(error);
          sendResponse({ error: `Đọc dữ liệu lỗi: ${error.message}` });
        })
      });



    }).catch(error => {
      sendResponse({ error: `Lỗi token: ${error.message}` });
    });
    return true;
  }
});
function getToken() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError); // Trả về lỗi nếu có
      } else {
        resolve(token); // Trả về token nếu thành công
      }
    });
  });
}
async function readGoogleSheetData(spreadsheetId, sheetName, token) {
  let allData = [];
  let startRow = 2; // Bắt đầu từ hàng 2 (bỏ qua tiêu đề nếu có)
  const batchSize = 10000;
  const delayMs = 1000; // Delay 1 giây giữa các request

  while (true) {
    const range = `${sheetName}!I${startRow}:I${startRow + batchSize - 1}`;
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}`;

    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        }
      });

      const data = await response.json();

      if (data.values) {
        allData = allData.concat(data.values);
        console.log(`Đã lấy ${data.values.length} dòng, tiếp tục...`);

        // Kiểm tra nếu số dòng trả về < batchSize thì dừng ngay lập tức
        if (data.values.length < batchSize) {
          console.log("Không còn dữ liệu, dừng ngay lập tức.");
          break;
        }

        startRow += batchSize; // Tăng startRow để lấy dữ liệu tiếp theo

        // Chờ 1 giây trước khi gửi request tiếp theo
        await new Promise(resolve => setTimeout(resolve, delayMs));
      } else {
        console.log("Không có dữ liệu mới, dừng lại.");
        break;
      }
    } catch (error) {
      console.error("Lỗi khi đọc Google Sheets:", error);
      break;
    }
  }

  return allData;
}


// Hàm cập nhật giá trị tại ô Nx
async function updateCells(spreadsheetId, sheetName, updates, token) {
  const batchSize = 100; // Giới hạn số ô cập nhật mỗi lần
  const delayMs = 1000; // Delay 1 giây giữa các batch

  for (let i = 0; i < updates.length; i += batchSize) {
    const batch = updates.slice(i, i + batchSize); // Lấy từng nhóm 100 cập nhật

    const requests = batch.map(({ position, value }) => ({
      range: `${sheetName}!${position}`, // Sử dụng tọa độ trực tiếp (A1, B3, C5, ...)
      values: [[value]],
    }));

    const requestBody = { data: requests, valueInputOption: "RAW" };

    try {
      const response = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(requestBody),
        }
      );

      const result = await response.json();
      console.log(`✅ Đã cập nhật ${batch.length} ô thành công`, result);

      // Nếu còn nhiều dữ liệu, chờ trước khi gửi tiếp
      if (i + batchSize < updates.length) {
        console.log(`⏳ Chờ ${delayMs / 1000} giây trước batch tiếp theo...`);
        await new Promise((resolve) => setTimeout(resolve, delayMs));
      }
    } catch (error) {
      console.error("❌ Lỗi khi cập nhật batch:", error);
    }
  }
}


function formatEndDate(dateString) {
  const date = new Date(dateString);  
  const day = String(date.getDate()); 
  const month = String(date.getMonth() + 1);
  const year = date.getFullYear(); 

  return `${day}/${month}/${year}`; 
}
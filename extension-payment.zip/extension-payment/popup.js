document.addEventListener("DOMContentLoaded", () => {
  $("#datePicker").flatpickr({
    dateFormat: "Y-m-d",  
    defaultDate: "today", 
    disableMobile: true,
    allowInput: true
});
$("#appt").flatpickr({
  enableTime: true,
  noCalendar: true,
  dateFormat: "H:i",
  allowInput: true
});


  const datePicker = document.getElementById("datePicker");
  const submitBtn = document.getElementById("submitBtn");
  const appTime = document.getElementById("appt");
  const setBtn = document.getElementById("setBtn");
  const result = document.getElementById("result");
  const excelBtn = document.getElementById("excelBtn");
  const resultSet = document.getElementById("resultSet");
  const excelText = document.getElementById("excelText");
  const urlAll = document.getElementById("url-all");
  const urlResult = document.getElementById("url-result");
  const urlChange = document.getElementById("url-change");
  const settingBtn = document.getElementById("settingBtn");
  const settingContent = document.getElementById("settingContent");


  // Get time from local
  chrome.storage.local.get('alarmTime', function(data) {
    appTime.value = data.alarmTime || "08:00";
  });
  chrome.storage.local.get('lastDate', function(data) {
    if (data.lastDate) {
      excelText.textContent = `Download ` + data.lastDate
    }
  })
  chrome.storage.local.get('urlAll', function(data) {
    if (data.urlAll) {
      urlAll.value = data.urlAll
    }
  });
  settingBtn.addEventListener('click', async() => {
    let isHidden = settingContent.style.display == "none";
    settingContent.style.display = isHidden ? "block" : "none";
  })
  urlChange.addEventListener('click', async() => {
    let urlVal = urlAll.value
    if (!urlVal || urlVal.length < 5) {
      urlResult.textContent = 'Vui lòng nhập url';
      return;
    }
    chrome.storage.local.set({ urlAll: urlVal }, function() {
      urlResult.textContent = 'Đã thay đổi url thành công: ' + urlAll.value;
    });
  })

  // ANCHOR
  datePicker.value = new Date().toISOString().split('T')[0];

  // Handle button click
  submitBtn.addEventListener("click", async () => {
    const selectedDate = datePicker.value;
    result.textContent = selectedDate 
      ? `You selected: ${selectedDate}`   
      : "Please select a date.";
      result.style.display = "block";

    // Send message to chrome runtime
    if (selectedDate) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      chrome.tabs.sendMessage(tab.id, {
        action: "update",  // Action to be performed in content.js
        date: selectedDate
      });
      console.log('Send message to chrome runtime');
    }
  });

  setBtn.addEventListener('click', async () => {
    const selectedTime = appTime.value;
    chrome.storage.local.set({ alarmTime: selectedTime }, function() {
      resultSet.textContent = 'Hẹn giờ thành công ' + selectedTime;
      resultSet.style.display = "block";
      console.log("Set time has been saved.");
    });
  })

  excelBtn.addEventListener('click', async () => {
    chrome.runtime.sendMessage({
      action: "excel"
    }, function(response) {
      if (response.success) {
        const link = document.createElement("a");
        link.href = "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64," + response.data;
        link.download = "danh_sach_payment.xlsx";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    })
  })

});

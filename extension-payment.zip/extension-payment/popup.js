document.addEventListener("DOMContentLoaded", () => {
  const today = new Date().toISOString().split("T")[0];
  $("#datePicker").flatpickr({
    dateFormat: "Y-m-d",  
    defaultDate: "today", 
    disableMobile: true,
    allowInput: true,
    mode: "range",
    defaultDate: [today, today],
});
$("#appt").flatpickr({
  enableTime: true,
  noCalendar: true,
  dateFormat: "H:i",
  allowInput: true,
  time_24hr: true
});


  const datePicker = document.getElementById("datePicker");
  const submitBtn = document.getElementById("submitBtn");
  const appTime = document.getElementById("appt");
  const setBtn = document.getElementById("setBtn");
  const result = document.getElementById("result");
  const excelBtn = document.getElementById("excelBtn");
  const resultSet = document.getElementById("resultSet");
  const excelText = document.getElementById("excelText");
  const settingBtn = document.getElementById("settingBtn");
  const settingContent = document.getElementById("settingContent");
  const switchTimer = document.getElementById("switchTimer");
  const timePicker = document.getElementById("timePicker");
  const sheetBtn = document.getElementById("sheetBtn");
  const sheetText = document.getElementById("sheetText");
  const resultSheet = document.getElementById("resultSheet");
  const sheetSpinner = document.getElementById("sheetSpinner");
  const urlInput = document.getElementById("url-input");
  const sheetIdInput = document.getElementById("sheetid");
  const sheetNameInput = document.getElementById("sheetname");
  const settingSaveButton = document.getElementById("setting-save");
  const settingResult = document.getElementById("setting-result");

  chrome.storage.local.get('switchTimer', function(data) {
    if (data.switchTimer) {
      switchTimer.checked = data.switchTimer;
      timePicker.style.display = data.switchTimer ? "block" : "none";
    } else {
      switchTimer.checked = false;
    }
  })
  switchTimer.addEventListener('change', async() => {
    chrome.storage.local.set({ switchTimer: switchTimer.checked }, function() {
      timePicker.style.display = switchTimer.checked? "block" : "none";
      if (switchTimer.checked) {
        chrome.runtime.sendMessage({
          action: "startTimer",
          alarmTime: appTime.value
        });
      } else {
        chrome.runtime.sendMessage({
          action: "stopTimer"
        })
      }
    });
  })

  // Get time from local
  chrome.storage.local.get('alarmTime', function(data) {
    appTime.value = data.alarmTime || "08:00";
  });
  chrome.storage.local.get('lastDate', function(data) {
    if (data.lastDate) {
      excelText.textContent = `Download ` + data.lastDate
      sheetText.textContent = `Update sheet ` + data.lastDate
    }
  })
  chrome.storage.local.get('urlAll', function(data) {
    if (data.urlAll) {
      urlInput.value = data.urlAll
    }
  });
  chrome.storage.local.get('sheetId', function(data) {
    if (data.sheetId) {
      sheetIdInput.value = data.sheetId
    }
  })
  chrome.storage.local.get('sheetName', function(data) {
    if (data.sheetName) {
      sheetNameInput.value = data.sheetName;
    }
  });
  settingSaveButton.addEventListener('click', function(e) {
    const url = urlInput.value;
    const sheetId = sheetIdInput.value;
    const sheetName = sheetNameInput.value;

    chrome.storage.local.set({ urlAll: url, sheetId: sheetId, sheetName: sheetName }, function() {
      console.log("Settings have been saved.");
      settingResult.textContent = "Lưu cài đặt thành công.";
    });
  })

  settingBtn.addEventListener('click', async() => {
    let isHidden = settingContent.style.display == "none";
    settingContent.style.display = isHidden ? "flex" : "none";
  })

  // Handle button click
  submitBtn.addEventListener("click", async () => {
    var selectedDate = datePicker.value;
    result.textContent = selectedDate 
      ? `You selected: ${selectedDate}`   
      : "Please select a date.";
      result.style.display = "block";

    if (!selectedDate) return;
    selectedDate = selectedDate.split(" to ");

    // Send message to chrome runtime
    if (selectedDate && selectedDate.length > 0) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      chrome.tabs.sendMessage(tab.id, {
        action: "update",  // Action to be performed in content.js
        date: selectedDate
      });
      console.log('Send message to chrome runtime');
    }
  });

  setBtn.addEventListener('click', async () => {
    const selectedTime = appTime.value;
    chrome.storage.local.set({ alarmTime: selectedTime }, function() {
      resultSet.textContent = 'Hẹn giờ thành công ' + selectedTime;
      resultSet.style.display = "block";
      console.log("Set time has been saved.");
    });
  })

  excelBtn.addEventListener('click', async () => {
    console.log("click")
    chrome.runtime.sendMessage({
      action: "excel"
    }, function(response) {
      if (response.success) {
        const link = document.createElement("a");
        link.href = "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64," + response.data;
        chrome.storage.local.get('lastDate', function(data) {
          const lastDate = `_${data.lastDate}` || "";
          link.download = `danh_sach_payment${lastDate}.xlsx`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        });
    }
    })
  });

  sheetBtn.addEventListener('click', async () => {  
    sheetSpinner.style.display = 'inline-block';
    resultSheet.style.display = 'none';
    chrome.runtime.sendMessage({ action: "updateSheet" }, (response) => {
      if (chrome.runtime.lastError) {
        console.error("Lỗi khi gửi tin nhắn:", chrome.runtime.lastError);
        resultSheet.textContent = "Lỗi khi gửi yêu cầu cập nhật.";
        resultSheet.style.display = "block";
        return;
      }
      if (response.error) {
        console.error("Lỗi từ background script:", response.error);
        resultSheet.textContent = response.error;
        resultSheet.style.display = "block";
      } else {
        resultSheet.textContent = "Cập nhật sheet thành công.";
        resultSheet.style.display = "block";
        resultSheet.style.color = "green";
      }
      sheetSpinner.style.display = 'none';
    });
  });
  

});

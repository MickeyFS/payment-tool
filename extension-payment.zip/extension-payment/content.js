const filterRows = (tempDate = null) => {    
  if (!tempDate) {
    const currentDate = new Date();
    tempDate = currentDate.toISOString().split('T')[0];
  }
  const listDeposit = document.getElementById('listDeposit');
  if (!listDeposit) {
    console.log("No 'listDeposit' element found.");
    return;
  }
  const completedLabels = document.querySelectorAll("a.ui.label.tiny.green");

  if (completedLabels.length === 0) {
    console.log("No matching 'Đã hoàn tất' elements found.");
    return;
  }
  tmp = 1;
  completedLabels.forEach((label) => {
    if (label.textContent.trim() === "Đã hoàn tất") {
      const parentRow = label.closest('tr');
      if (!parentRow) return;

      const dateColumn = parentRow.querySelectorAll("td")[6];
      if (!dateColumn) return;

      const dateText = dateColumn.textContent.trim().split(" ")[0]; 
      if (dateText != tempDate) return;

      const firstTdAnchor = parentRow.querySelector('td:first-child a');
      if (!firstTdAnchor) return;

      const paymentId = firstTdAnchor.innerText.trim();

      console.log(tmp++);
      console.log(firstTdAnchor.innerText)

      // ANCHOR - need to change
      const href = firstTdAnchor.getAttribute('href');
      console.log(href)
      chrome.runtime.sendMessage({ action: "openDetailPage", url: href, paymentId: paymentId, date: tempDate });
      // file:///Users/emic/Documents/payment/Archive/Bo%20KT%204.0.html
    }
  });
}

window.onload = () => {
  console.log("Window loaded");
  const observer = new MutationObserver(() => { filterRows() });
  observer.observe(document.body, { childList: true, subtree: true });
  console.log("Observer attached");
};

chrome.runtime.onMessage.addListener((  message, sender, sendResponse) => {
  if (message.action === "update") {
    console.log("Received message from background.js:", message.date);  // Get data from background.js
    filterRows(message.date);
  }
})
# Tải Extension Payment

Bạn có thể tải xuống **Payment Extension** từ liên kết dưới đây:

[Download Payment Extension](https://github.com/MickeyFS/payment-tool/blob/d7f5030bd2f4501e5d33fb94ee33741a6ebf250d/extension-payment.zip)

Nhấp vào liên kết để bắt đầu tải về tệp `extension-payment.zip`.
